import React from 'react'
import '../styles/navbar.css'

const Footer = () => {
  return (
    <div>
      <footer className="App-footer">
        <p>© 2024</p>
      </footer>
    </div>
  )
}

export default Footer
