import { createContext, useContext, useState, useEffect } from "react";
import { initializeApp } from "firebase/app";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  signOut,
  RecaptchaVerifier,
  signInWithPhoneNumber,
} from "firebase/auth";
import {getFirestore, collection, addDoc } from 'firebase/firestore'

const FirebaseContext = createContext(null);

const firebaseConfig = {
  apiKey: "AIzaSyDTgak8YGYdtN0rHJezSZjURfFyaujOcM4",
  authDomain: "kaustubhamedtech-9cc39.firebaseapp.com",
  projectId: "kaustubhamedtech-9cc39",
  storageBucket: "kaustubhamedtech-9cc39.appspot.com",
  messagingSenderId: "829842970757",
  appId: "1:829842970757:web:56cc2e9d69ccd04f0ef1ec",
  measurementId: "G-PH4B8LBQXP",
};

const app = initializeApp(firebaseConfig);
export const firebaseAuth = getAuth(app);
const firestore = getFirestore(app);
firebaseAuth.useDeviceLanguage();

export const useFirebase = () => {
  return useContext(FirebaseContext);
};

export const FirebaseProvider = (props) => {

  // user and user-details
  const [user, setUser] = useState(null);
  const [userDetails, setUserDetails] = useState(null);
  const [confirmationResult, setConfirmationResult] = useState(null);

  useEffect(() => {
    onAuthStateChanged(firebaseAuth, (user) => {
      if (user) {
        setUser(user);
        setUserDetails({
          email: user.email,
          emailVerified: user.emailVerified,
          // add other details you want to track
        });
        console.log(user);
      } else {
        setUser(null);
      }
    });
  }, []);

  useEffect(() => {
    if (user) {
      // Update userDetails here
      setUserDetails({
        email: user.email,
        emailVerified: user.emailVerified,
        phoneNumber: user.phoneNumber,
        // add other details you want to track
      });
    } else {
      setUserDetails(null);
    }
  }, [user]);

  const signupUserWithEmailAndPassword = async (email, password) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(
        firebaseAuth,
        email,
        password
      );
      const user = userCredential.user;
      return user;
    } catch (error) {
      return error;
    }
  };

  const signinUserWithEmailAndPassword = async (email, password) => {
    try {
      const userCredential = await signInWithEmailAndPassword(
        firebaseAuth,
        email,
        password
      );
      const user = userCredential.user;
      console.log(user);
      console.log(userDetails);
      if(user.emailVerified === false){
        await sendEmailVerification(user);
        console.log("Email sent")
      }
      return user;
    } catch (error) {
      return error;
    }
  };

  const signupUserAndVerification = async (email, password, backupPhone) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(
        firebaseAuth,
        email,
        password
      )
      const userDatainDB = await addDoc(collection(firestore, 'users'), {
        userId: userCredential.user?.uid,
        signupEmail: userCredential.user?.email,
        signupPhone: backupPhone,
      });
      console.log(userDatainDB);
      console.log(userCredential)
      setUserDetails({
        email: userCredential.user.email,
        emailVerified: userCredential.user.emailVerified,
      });
      const user = userCredential.user;
      await sendEmailVerification(user);
      console.log("Email sent")
      return user;
    } catch (error) {
      return error;
    }
  };

  const logout = async () => {
    try {
      await signOut(firebaseAuth);
      console.log("Logged out");
      console.log(user);
    } catch (error) {
      return error;
    }
  }


  const sendOtp = async (number) => {
    try {
      const recaptcha = new RecaptchaVerifier(firebaseAuth, "recaptcha", {});
      const confirmation = await signInWithPhoneNumber(firebaseAuth, number, recaptcha);
      setConfirmationResult(confirmation);
      return confirmation; 
    } catch (error) {
      return error;
    }
  }

  const otpVerification = async (otp,backupEmail) => {
    try {
      const data = await confirmationResult.confirm(otp);
      console.log(data);
      console.log("OTP verified");
      const userDatainDB = await addDoc(collection(firestore, 'users'), {
        userId: data.user?.uid,
        signupPhone: data.user?.phoneNumber,
        signupEmail: backupEmail,
      });
      console.log(userDatainDB);
      setUser(data.user);
      console.log(user);
      return data;
    }
    catch (error) {
      return error;
    }
  }



  const handleCreateUserData = async (name, age, gender, address, phone, altEmail) => {
    try {
      return await addDoc(collection(firestore, 'users'), {
        name: name,
        alternate_email: altEmail,
        age: age,
        gender: gender,
        address: address,
        phone: phone,
        userId: user.uid,
        userEmail: user.email,
        displayName: user.displayName,
      });
      console.log("Document stored successfully");
    } catch (error) {
      console.log(error);
    }
  };



  const isLoggedin = user ? true : false;

  return (
    <FirebaseContext.Provider
      value={{
        signupUserWithEmailAndPassword,
        signinUserWithEmailAndPassword,
        signupUserAndVerification,
        userDetails,
        sendOtp,
        otpVerification,
        isLoggedin,
        user,
        handleCreateUserData,
        logout,
      }}
    >
      {props.children}
    </FirebaseContext.Provider>
  );
};
